import express from 'express';
import { check } from 'express-validator';
import pool from '../config/db.js';
import { authenticateToken, authorizeRole, validateRequest } from '../middleware/auth.js';

const router = express.Router();

// Get attendance records for a course
router.get('/course/:courseId',
    authenticateToken,
    async (req, res) => {
        try {
            const courseId = req.params.courseId;

            // Check if course exists
            const [courses] = await pool.query('SELECT faculty_id FROM courses WHERE id = ?', [courseId]);
            if (courses.length === 0) {
                return res.status(404).json({
                    success: false,
                    message: 'Course not found'
                });
            }

            // If user is a teacher, verify they are assigned to this course
            if (req.user.role === 'teacher') {
                const [faculty] = await pool.query('SELECT id FROM faculty WHERE user_id = ?', [req.user.id]);
                if (faculty.length === 0 || faculty[0].id !== courses[0].faculty_id) {
                    return res.status(403).json({
                        success: false,
                        message: 'Access denied'
                    });
                }
            }

            const [attendance] = await pool.query(
                `SELECT a.*, s.first_name, s.last_name
                FROM attendance a
                JOIN students s ON a.student_id = s.id
                WHERE a.course_id = ?
                ORDER BY a.date DESC, s.last_name, s.first_name`,
                [courseId]
            );

            res.json({
                success: true,
                attendance
            });
        } catch (error) {
            console.error(error);
            res.status(500).json({
                success: false,
                message: 'Error fetching attendance records'
            });
        }
    }
);

// Get attendance records for a student
router.get('/student/:studentId',
    authenticateToken,
    async (req, res) => {
        try {
            const studentId = req.params.studentId;

            // Check if student exists
            const [students] = await pool.query('SELECT user_id FROM students WHERE id = ?', [studentId]);
            if (students.length === 0) {
                return res.status(404).json({
                    success: false,
                    message: 'Student not found'
                });
            }

            // Check if user has permission to view this student's attendance
            if (req.user.role === 'student' && req.user.id !== students[0].user_id) {
                return res.status(403).json({
                    success: false,
                    message: 'Access denied'
                });
            }

            const [attendance] = await pool.query(
                `SELECT a.*, c.course_code, c.course_name
                FROM attendance a
                JOIN courses c ON a.course_id = c.id
                WHERE a.student_id = ?
                ORDER BY a.date DESC, c.course_code`,
                [studentId]
            );

            res.json({
                success: true,
                attendance
            });
        } catch (error) {
            console.error(error);
            res.status(500).json({
                success: false,
                message: 'Error fetching attendance records'
            });
        }
    }
);

// Record attendance (teacher only)
router.post('/',
    authenticateToken,
    authorizeRole('teacher'),
    [
        check('course_id').notEmpty().withMessage('Course ID is required'),
        check('student_id').notEmpty().withMessage('Student ID is required'),
        check('date').isDate().withMessage('Valid date is required'),
        check('status').isIn(['present', 'absent', 'late']).withMessage('Invalid attendance status')
    ],
    validateRequest,
    async (req, res) => {
        try {
            const { course_id, student_id, date, status } = req.body;

            // Check if course exists and teacher is assigned to it
            const [courses] = await pool.query('SELECT faculty_id FROM courses WHERE id = ?', [course_id]);
            if (courses.length === 0) {
                return res.status(404).json({
                    success: false,
                    message: 'Course not found'
                });
            }

            const [faculty] = await pool.query('SELECT id FROM faculty WHERE user_id = ?', [req.user.id]);
            if (faculty.length === 0 || faculty[0].id !== courses[0].faculty_id) {
                return res.status(403).json({
                    success: false,
                    message: 'You are not authorized to record attendance for this course'
                });
            }

            // Check if student is enrolled in the course
            const [enrollment] = await pool.query(
                'SELECT id FROM student_courses WHERE student_id = ? AND course_id = ?',
                [student_id, course_id]
            );
            if (enrollment.length === 0) {
                return res.status(400).json({
                    success: false,
                    message: 'Student is not enrolled in this course'
                });
            }

            // Check if attendance already recorded for this date
            const [existingAttendance] = await pool.query(
                'SELECT id FROM attendance WHERE student_id = ? AND course_id = ? AND date = ?',
                [student_id, course_id, date]
            );

            if (existingAttendance.length > 0) {
                // Update existing attendance
                await pool.query(
                    'UPDATE attendance SET status = ? WHERE student_id = ? AND course_id = ? AND date = ?',
                    [status, student_id, course_id, date]
                );

                res.json({
                    success: true,
                    message: 'Attendance updated successfully'
                });
            } else {
                // Record new attendance
                await pool.query(
                    'INSERT INTO attendance (student_id, course_id, date, status) VALUES (?, ?, ?, ?)',
                    [student_id, course_id, date, status]
                );

                res.status(201).json({
                    success: true,
                    message: 'Attendance recorded successfully'
                });
            }
        } catch (error) {
            console.error(error);
            res.status(500).json({
                success: false,
                message: 'Error recording attendance'
            });
        }
    }
);

// Bulk record attendance (teacher only)
router.post('/bulk',
    authenticateToken,
    authorizeRole('teacher'),
    [
        check('course_id').notEmpty().withMessage('Course ID is required'),
        check('date').isDate().withMessage('Valid date is required'),
        check('attendance').isArray().withMessage('Attendance records must be an array'),
        check('attendance.*.student_id').notEmpty().withMessage('Student ID is required for each record'),
        check('attendance.*.status').isIn(['present', 'absent', 'late']).withMessage('Invalid attendance status')
    ],
    validateRequest,
    async (req, res) => {
        try {
            const { course_id, date, attendance } = req.body;

            // Check if course exists and teacher is assigned to it
            const [courses] = await pool.query('SELECT faculty_id FROM courses WHERE id = ?', [course_id]);
            if (courses.length === 0) {
                return res.status(404).json({
                    success: false,
                    message: 'Course not found'
                });
            }

            const [faculty] = await pool.query('SELECT id FROM faculty WHERE user_id = ?', [req.user.id]);
            if (faculty.length === 0 || faculty[0].id !== courses[0].faculty_id) {
                return res.status(403).json({
                    success: false,
                    message: 'You are not authorized to record attendance for this course'
                });
            }

            // Start transaction
            const connection = await pool.getConnection();
            await connection.beginTransaction();

            try {
                for (const record of attendance) {
                    const { student_id, status } = record;

                    // Check if student is enrolled
                    const [enrollment] = await connection.query(
                        'SELECT id FROM student_courses WHERE student_id = ? AND course_id = ?',
                        [student_id, course_id]
                    );
                    if (enrollment.length === 0) {
                        continue; // Skip students not enrolled in the course
                    }

                    // Update or insert attendance record
                    await connection.query(
                        `INSERT INTO attendance (student_id, course_id, date, status)
                        VALUES (?, ?, ?, ?)
                        ON DUPLICATE KEY UPDATE status = ?`,
                        [student_id, course_id, date, status, status]
                    );
                }

                await connection.commit();
                res.json({
                    success: true,
                    message: 'Bulk attendance recorded successfully'
                });
            } catch (error) {
                await connection.rollback();
                throw error;
            } finally {
                connection.release();
            }
        } catch (error) {
            console.error(error);
            res.status(500).json({
                success: false,
                message: 'Error recording bulk attendance'
            });
        }
    }
);

export default router;