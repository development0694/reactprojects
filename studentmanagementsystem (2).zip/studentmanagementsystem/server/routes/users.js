import express from 'express';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { check } from 'express-validator';
import pool from '../config/db.js';
import { authenticateToken, authorizeRole, validateRequest } from '../middleware/auth.js';

const router = express.Router();

// Register user
router.post('/register',
    [
        check('username').notEmpty().withMessage('Username is required'),
        check('password').isLength({ min: 6 }).withMessage('Password must be at least 6 characters long'),
        check('role').isIn(['admin', 'teacher', 'student']).withMessage('Invalid role')
    ],
    validateRequest,
    async (req, res) => {
        try {
            const { username, password, role } = req.body;

            // Check if user already exists
            const [existingUser] = await pool.query('SELECT id FROM users WHERE username = ?', [username]);
            if (existingUser.length > 0) {
                return res.status(400).json({
                    success: false,
                    message: 'Username already exists'
                });
            }

            // Hash password
            const salt = await bcrypt.genSalt(10);
            const hashedPassword = await bcrypt.hash(password, salt);

            // Insert user
            const [result] = await pool.query(
                'INSERT INTO users (username, password, role) VALUES (?, ?, ?)',
                [username, hashedPassword, role]
            );

            res.status(201).json({
                success: true,
                message: 'User registered successfully',
                userId: result.insertId
            });
        } catch (error) {
            console.error(error);
            res.status(500).json({
                success: false,
                message: 'Error registering user'
            });
        }
    }
);

// Login user
router.post('/login',
    [
        check('username').notEmpty().withMessage('Username is required'),
        check('password').notEmpty().withMessage('Password is required')
    ],
    validateRequest,
    async (req, res) => {
        try {
            const { username, password } = req.body;

            // Get user
            const [users] = await pool.query('SELECT * FROM users WHERE username = ?', [username]);
            if (users.length === 0) {
                return res.status(401).json({
                    success: false,
                    message: 'Invalid credentials'
                });
            }

            const user = users[0];

            // Check password
            const isMatch = await bcrypt.compare(password, user.password);
            if (!isMatch) {
                return res.status(401).json({
                    success: false,
                    message: 'Invalid credentials'
                });
            }

            // Generate JWT token
            const token = jwt.sign(
                { id: user.id, role: user.role },
                process.env.JWT_SECRET,
                { expiresIn: process.env.JWT_EXPIRES_IN }
            );

            res.json({
                success: true,
                token,
                user: {
                    id: user.id,
                    username: user.username,
                    role: user.role
                }
            });
        } catch (error) {
            console.error(error);
            res.status(500).json({
                success: false,
                message: 'Error logging in'
            });
        }
    }
);

// Get user profile
router.get('/profile', authenticateToken, async (req, res) => {
    try {
        const [users] = await pool.query('SELECT id, username, role FROM users WHERE id = ?', [req.user.id]);
        if (users.length === 0) {
            return res.status(404).json({
                success: false,
                message: 'User not found'
            });
        }

        res.json({
            success: true,
            user: users[0]
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({
            success: false,
            message: 'Error fetching user profile'
        });
    }
});

// Update user profile
router.put('/profile',
    authenticateToken,
    [
        check('password').optional().isLength({ min: 6 }).withMessage('Password must be at least 6 characters long')
    ],
    validateRequest,
    async (req, res) => {
        try {
            const { password } = req.body;

            if (password) {
                const salt = await bcrypt.genSalt(10);
                const hashedPassword = await bcrypt.hash(password, salt);

                await pool.query('UPDATE users SET password = ? WHERE id = ?', [hashedPassword, req.user.id]);
            }

            res.json({
                success: true,
                message: 'Profile updated successfully'
            });
        } catch (error) {
            console.error(error);
            res.status(500).json({
                success: false,
                message: 'Error updating profile'
            });
        }
    }
);

export default router;