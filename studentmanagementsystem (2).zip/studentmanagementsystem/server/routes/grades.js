import express from 'express';
import { check } from 'express-validator';
import pool from '../config/db.js';
import { authenticateToken, authorizeRole, validateRequest } from '../middleware/auth.js';

const router = express.Router();

// Get grades for a course
router.get('/course/:courseId',
    authenticateToken,
    async (req, res) => {
        try {
            const courseId = req.params.courseId;

            // Check if course exists
            const [courses] = await pool.query('SELECT faculty_id FROM courses WHERE id = ?', [courseId]);
            if (courses.length === 0) {
                return res.status(404).json({
                    success: false,
                    message: 'Course not found'
                });
            }

            // If user is a teacher, verify they are assigned to this course
            if (req.user.role === 'teacher') {
                const [faculty] = await pool.query('SELECT id FROM faculty WHERE user_id = ?', [req.user.id]);
                if (faculty.length === 0 || faculty[0].id !== courses[0].faculty_id) {
                    return res.status(403).json({
                        success: false,
                        message: 'Access denied'
                    });
                }
            }

            const [grades] = await pool.query(
                `SELECT g.*, s.first_name, s.last_name
                FROM grades g
                JOIN students s ON g.student_id = s.id
                WHERE g.course_id = ?
                ORDER BY s.last_name, s.first_name, g.date_assigned DESC`,
                [courseId]
            );

            res.json({
                success: true,
                grades
            });
        } catch (error) {
            console.error(error);
            res.status(500).json({
                success: false,
                message: 'Error fetching grades'
            });
        }
    }
);

// Get grades for a student
router.get('/student/:studentId',
    authenticateToken,
    async (req, res) => {
        try {
            const studentId = req.params.studentId;

            // Check if student exists
            const [students] = await pool.query('SELECT user_id FROM students WHERE id = ?', [studentId]);
            if (students.length === 0) {
                return res.status(404).json({
                    success: false,
                    message: 'Student not found'
                });
            }

            // Check if user has permission to view this student's grades
            if (req.user.role === 'student' && req.user.id !== students[0].user_id) {
                return res.status(403).json({
                    success: false,
                    message: 'Access denied'
                });
            }

            const [grades] = await pool.query(
                `SELECT g.*, c.course_code, c.course_name
                FROM grades g
                JOIN courses c ON g.course_id = c.id
                WHERE g.student_id = ?
                ORDER BY g.date_assigned DESC, c.course_code`,
                [studentId]
            );

            res.json({
                success: true,
                grades
            });
        } catch (error) {
            console.error(error);
            res.status(500).json({
                success: false,
                message: 'Error fetching grades'
            });
        }
    }
);

// Record grade (teacher only)
router.post('/',
    authenticateToken,
    authorizeRole('teacher'),
    [
        check('course_id').notEmpty().withMessage('Course ID is required'),
        check('student_id').notEmpty().withMessage('Student ID is required'),
        check('grade_type').notEmpty().withMessage('Grade type is required'),
        check('grade').isFloat({ min: 0, max: 100 }).withMessage('Grade must be between 0 and 100')
    ],
    validateRequest,
    async (req, res) => {
        try {
            const { course_id, student_id, grade_type, grade } = req.body;

            // Check if course exists and teacher is assigned to it
            const [courses] = await pool.query('SELECT faculty_id FROM courses WHERE id = ?', [course_id]);
            if (courses.length === 0) {
                return res.status(404).json({
                    success: false,
                    message: 'Course not found'
                });
            }

            const [faculty] = await pool.query('SELECT id FROM faculty WHERE user_id = ?', [req.user.id]);
            if (faculty.length === 0 || faculty[0].id !== courses[0].faculty_id) {
                return res.status(403).json({
                    success: false,
                    message: 'You are not authorized to record grades for this course'
                });
            }

            // Check if student is enrolled in the course
            const [enrollment] = await pool.query(
                'SELECT id FROM student_courses WHERE student_id = ? AND course_id = ?',
                [student_id, course_id]
            );
            if (enrollment.length === 0) {
                return res.status(400).json({
                    success: false,
                    message: 'Student is not enrolled in this course'
                });
            }

            // Record grade
            await pool.query(
                'INSERT INTO grades (student_id, course_id, grade_type, grade, date_assigned) VALUES (?, ?, ?, ?, CURDATE())',
                [student_id, course_id, grade_type, grade]
            );

            res.status(201).json({
                success: true,
                message: 'Grade recorded successfully'
            });
        } catch (error) {
            console.error(error);
            res.status(500).json({
                success: false,
                message: 'Error recording grade'
            });
        }
    }
);

// Update grade (teacher only)
router.put('/:id',
    authenticateToken,
    authorizeRole('teacher'),
    [
        check('grade').isFloat({ min: 0, max: 100 }).withMessage('Grade must be between 0 and 100')
    ],
    validateRequest,
    async (req, res) => {
        try {
            const gradeId = req.params.id;
            const { grade } = req.body;

            // Check if grade record exists and teacher has permission
            const [grades] = await pool.query(
                `SELECT g.*, c.faculty_id
                FROM grades g
                JOIN courses c ON g.course_id = c.id
                WHERE g.id = ?`,
                [gradeId]
            );

            if (grades.length === 0) {
                return res.status(404).json({
                    success: false,
                    message: 'Grade record not found'
                });
            }

            const [faculty] = await pool.query('SELECT id FROM faculty WHERE user_id = ?', [req.user.id]);
            if (faculty.length === 0 || faculty[0].id !== grades[0].faculty_id) {
                return res.status(403).json({
                    success: false,
                    message: 'You are not authorized to update this grade'
                });
            }

            // Update grade
            await pool.query(
                'UPDATE grades SET grade = ? WHERE id = ?',
                [grade, gradeId]
            );

            res.json({
                success: true,
                message: 'Grade updated successfully'
            });
        } catch (error) {
            console.error(error);
            res.status(500).json({
                success: false,
                message: 'Error updating grade'
            });
        }
    }
);

// Bulk record grades (teacher only)
router.post('/bulk',
    authenticateToken,
    authorizeRole('teacher'),
    [
        check('course_id').notEmpty().withMessage('Course ID is required'),
        check('grade_type').notEmpty().withMessage('Grade type is required'),
        check('grades').isArray().withMessage('Grades must be an array'),
        check('grades.*.student_id').notEmpty().withMessage('Student ID is required for each grade'),
        check('grades.*.grade').isFloat({ min: 0, max: 100 }).withMessage('Grade must be between 0 and 100')
    ],
    validateRequest,
    async (req, res) => {
        try {
            const { course_id, grade_type, grades } = req.body;

            // Check if course exists and teacher is assigned to it
            const [courses] = await pool.query('SELECT faculty_id FROM courses WHERE id = ?', [course_id]);
            if (courses.length === 0) {
                return res.status(404).json({
                    success: false,
                    message: 'Course not found'
                });
            }

            const [faculty] = await pool.query('SELECT id FROM faculty WHERE user_id = ?', [req.user.id]);
            if (faculty.length === 0 || faculty[0].id !== courses[0].faculty_id) {
                return res.status(403).json({
                    success: false,
                    message: 'You are not authorized to record grades for this course'
                });
            }

            // Start transaction
            const connection = await pool.getConnection();
            await connection.beginTransaction();

            try {
                for (const record of grades) {
                    const { student_id, grade } = record;

                    // Check if student is enrolled
                    const [enrollment] = await connection.query(
                        'SELECT id FROM student_courses WHERE student_id = ? AND course_id = ?',
                        [student_id, course_id]
                    );
                    if (enrollment.length === 0) {
                        continue; // Skip students not enrolled in the course
                    }

                    // Record grade
                    await connection.query(
                        'INSERT INTO grades (student_id, course_id, grade_type, grade, date_assigned) VALUES (?, ?, ?, ?, CURDATE())',
                        [student_id, course_id, grade_type, grade]
                    );
                }

                await connection.commit();
                res.json({
                    success: true,
                    message: 'Bulk grades recorded successfully'
                });
            } catch (error) {
                await connection.rollback();
                throw error;
            } finally {
                connection.release();
            }
        } catch (error) {
            console.error(error);
            res.status(500).json({
                success: false,
                message: 'Error recording bulk grades'
            });
        }
    }
);

export default router;