import express from 'express';
import { check } from 'express-validator';
import pool from '../config/db.js';
import { authenticateToken, authorizeRole, validateRequest } from '../middleware/auth.js';

const router = express.Router();

// Get all courses
router.get('/', authenticateToken, async (req, res) => {
    try {
        const [courses] = await pool.query(
            `SELECT c.*, f.first_name as faculty_first_name, f.last_name as faculty_last_name
            FROM courses c
            LEFT JOIN faculty f ON c.faculty_id = f.id`
        );
        res.json({
            success: true,
            courses
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({
            success: false,
            message: 'Error fetching courses'
        });
    }
});

// Get course by ID
router.get('/:id', authenticateToken, async (req, res) => {
    try {
        const [courses] = await pool.query(
            `SELECT c.*, f.first_name as faculty_first_name, f.last_name as faculty_last_name
            FROM courses c
            LEFT JOIN faculty f ON c.faculty_id = f.id
            WHERE c.id = ?`,
            [req.params.id]
        );

        if (courses.length === 0) {
            return res.status(404).json({
                success: false,
                message: 'Course not found'
            });
        }

        res.json({
            success: true,
            course: courses[0]
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({
            success: false,
            message: 'Error fetching course'
        });
    }
});

// Create course (admin only)
router.post('/',
    authenticateToken,
    authorizeRole('admin'),
    [
        check('course_code').notEmpty().withMessage('Course code is required'),
        check('course_name').notEmpty().withMessage('Course name is required'),
        check('credits').isInt({ min: 1 }).withMessage('Credits must be a positive integer')
    ],
    validateRequest,
    async (req, res) => {
        try {
            const { course_code, course_name, description, credits, faculty_id } = req.body;

            // Check if course code already exists
            const [existingCourse] = await pool.query('SELECT id FROM courses WHERE course_code = ?', [course_code]);
            if (existingCourse.length > 0) {
                return res.status(400).json({
                    success: false,
                    message: 'Course code already exists'
                });
            }

            // Check if faculty exists if faculty_id is provided
            if (faculty_id) {
                const [faculty] = await pool.query('SELECT id FROM faculty WHERE id = ?', [faculty_id]);
                if (faculty.length === 0) {
                    return res.status(400).json({
                        success: false,
                        message: 'Faculty not found'
                    });
                }
            }

            const [result] = await pool.query(
                'INSERT INTO courses (course_code, course_name, description, credits, faculty_id) VALUES (?, ?, ?, ?, ?)',
                [course_code, course_name, description, credits, faculty_id]
            );

            res.status(201).json({
                success: true,
                message: 'Course created successfully',
                courseId: result.insertId
            });
        } catch (error) {
            console.error(error);
            res.status(500).json({
                success: false,
                message: 'Error creating course'
            });
        }
    }
);

// Update course (admin only)
router.put('/:id',
    authenticateToken,
    authorizeRole('admin'),
    [
        check('course_code').optional().notEmpty().withMessage('Course code cannot be empty'),
        check('course_name').optional().notEmpty().withMessage('Course name cannot be empty'),
        check('credits').optional().isInt({ min: 1 }).withMessage('Credits must be a positive integer')
    ],
    validateRequest,
    async (req, res) => {
        try {
            const courseId = req.params.id;
            const { course_code, course_name, description, credits, faculty_id } = req.body;

            // Check if course exists
            const [courses] = await pool.query('SELECT id FROM courses WHERE id = ?', [courseId]);
            if (courses.length === 0) {
                return res.status(404).json({
                    success: false,
                    message: 'Course not found'
                });
            }

            // Check if course code is unique if updating
            if (course_code) {
                const [existingCourse] = await pool.query(
                    'SELECT id FROM courses WHERE course_code = ? AND id != ?',
                    [course_code, courseId]
                );
                if (existingCourse.length > 0) {
                    return res.status(400).json({
                        success: false,
                        message: 'Course code already exists'
                    });
                }
            }

            // Check if faculty exists if faculty_id is provided
            if (faculty_id) {
                const [faculty] = await pool.query('SELECT id FROM faculty WHERE id = ?', [faculty_id]);
                if (faculty.length === 0) {
                    return res.status(400).json({
                        success: false,
                        message: 'Faculty not found'
                    });
                }
            }

            await pool.query(
                'UPDATE courses SET course_code = COALESCE(?, course_code), course_name = COALESCE(?, course_name), description = COALESCE(?, description), credits = COALESCE(?, credits), faculty_id = COALESCE(?, faculty_id) WHERE id = ?',
                [course_code, course_name, description, credits, faculty_id, courseId]
            );

            res.json({
                success: true,
                message: 'Course updated successfully'
            });
        } catch (error) {
            console.error(error);
            res.status(500).json({
                success: false,
                message: 'Error updating course'
            });
        }
    }
);

// Enroll student in course
router.post('/:id/enroll',
    authenticateToken,
    [
        check('student_id').notEmpty().withMessage('Student ID is required')
    ],
    validateRequest,
    async (req, res) => {
        try {
            const courseId = req.params.id;
            const { student_id } = req.body;

            // Check if course exists
            const [courses] = await pool.query('SELECT id FROM courses WHERE id = ?', [courseId]);
            if (courses.length === 0) {
                return res.status(404).json({
                    success: false,
                    message: 'Course not found'
                });
            }

            // Check if student exists
            const [students] = await pool.query('SELECT user_id FROM students WHERE id = ?', [student_id]);
            if (students.length === 0) {
                return res.status(404).json({
                    success: false,
                    message: 'Student not found'
                });
            }

            // Check if student is already enrolled
            const [enrollment] = await pool.query(
                'SELECT id FROM student_courses WHERE student_id = ? AND course_id = ?',
                [student_id, courseId]
            );
            if (enrollment.length > 0) {
                return res.status(400).json({
                    success: false,
                    message: 'Student is already enrolled in this course'
                });
            }

            // Enroll student
            await pool.query(
                'INSERT INTO student_courses (student_id, course_id, enrollment_date) VALUES (?, ?, CURDATE())',
                [student_id, courseId]
            );

            res.status(201).json({
                success: true,
                message: 'Student enrolled successfully'
            });
        } catch (error) {
            console.error(error);
            res.status(500).json({
                success: false,
                message: 'Error enrolling student'
            });
        }
    }
);

// Get enrolled students in a course
router.get('/:id/students',
    authenticateToken,
    async (req, res) => {
        try {
            const courseId = req.params.id;

            const [students] = await pool.query(
                `SELECT s.*, sc.enrollment_date, sc.status
                FROM students s
                JOIN student_courses sc ON s.id = sc.student_id
                WHERE sc.course_id = ?`,
                [courseId]
            );

            res.json({
                success: true,
                students
            });
        } catch (error) {
            console.error(error);
            res.status(500).json({
                success: false,
                message: 'Error fetching enrolled students'
            });
        }
    }
);

export default router;