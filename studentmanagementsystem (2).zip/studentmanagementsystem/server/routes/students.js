import express from 'express';
import { check } from 'express-validator';
import pool from '../config/db.js';
import { authenticateToken, authorizeRole, validateRequest } from '../middleware/auth.js';

const router = express.Router();

// Get all students (admin and teacher only)
router.get('/',
    authenticateToken,
    authorizeRole('admin', 'teacher'),
    async (req, res) => {
        try {
            const [students] = await pool.query(
                'SELECT s.*, u.username, u.role FROM students s JOIN users u ON s.user_id = u.id'
            );
            res.json({
                success: true,
                students
            });
        } catch (error) {
            console.error(error);
            res.status(500).json({
                success: false,
                message: 'Error fetching students'
            });
        }
    }
);

// Get student by ID
router.get('/:id',
    authenticateToken,
    async (req, res) => {
        try {
            const [students] = await pool.query(
                'SELECT s.*, u.username, u.role FROM students s JOIN users u ON s.user_id = u.id WHERE s.id = ?',
                [req.params.id]
            );

            if (students.length === 0) {
                return res.status(404).json({
                    success: false,
                    message: 'Student not found'
                });
            }

            // Check if user has permission to view this student
            if (req.user.role === 'student' && req.user.id !== students[0].user_id) {
                return res.status(403).json({
                    success: false,
                    message: 'Access denied'
                });
            }

            res.json({
                success: true,
                student: students[0]
            });
        } catch (error) {
            console.error(error);
            res.status(500).json({
                success: false,
                message: 'Error fetching student'
            });
        }
    }
);

// Create student profile (admin only)
router.post('/',
    authenticateToken,
    authorizeRole('admin'),
    [
        check('user_id').notEmpty().withMessage('User ID is required'),
        check('first_name').notEmpty().withMessage('First name is required'),
        check('last_name').notEmpty().withMessage('Last name is required'),
        check('email').isEmail().withMessage('Invalid email'),
        check('enrollment_date').isDate().withMessage('Invalid enrollment date')
    ],
    validateRequest,
    async (req, res) => {
        try {
            const { user_id, first_name, last_name, email, date_of_birth, address, phone, enrollment_date } = req.body;

            // Check if user exists and is a student
            const [users] = await pool.query('SELECT role FROM users WHERE id = ?', [user_id]);
            if (users.length === 0 || users[0].role !== 'student') {
                return res.status(400).json({
                    success: false,
                    message: 'Invalid user ID or user is not a student'
                });
            }

            // Check if student profile already exists
            const [existingStudent] = await pool.query('SELECT id FROM students WHERE user_id = ?', [user_id]);
            if (existingStudent.length > 0) {
                return res.status(400).json({
                    success: false,
                    message: 'Student profile already exists'
                });
            }

            const [result] = await pool.query(
                'INSERT INTO students (user_id, first_name, last_name, email, date_of_birth, address, phone, enrollment_date) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
                [user_id, first_name, last_name, email, date_of_birth, address, phone, enrollment_date]
            );

            res.status(201).json({
                success: true,
                message: 'Student profile created successfully',
                studentId: result.insertId
            });
        } catch (error) {
            console.error(error);
            res.status(500).json({
                success: false,
                message: 'Error creating student profile'
            });
        }
    }
);

// Update student profile
router.put('/:id',
    authenticateToken,
    [
        check('first_name').optional().notEmpty().withMessage('First name cannot be empty'),
        check('last_name').optional().notEmpty().withMessage('Last name cannot be empty'),
        check('email').optional().isEmail().withMessage('Invalid email')
    ],
    validateRequest,
    async (req, res) => {
        try {
            const studentId = req.params.id;
            const { first_name, last_name, email, date_of_birth, address, phone } = req.body;

            // Check if student exists
            const [students] = await pool.query('SELECT user_id FROM students WHERE id = ?', [studentId]);
            if (students.length === 0) {
                return res.status(404).json({
                    success: false,
                    message: 'Student not found'
                });
            }

            // Check if user has permission to update this student
            if (req.user.role === 'student' && req.user.id !== students[0].user_id) {
                return res.status(403).json({
                    success: false,
                    message: 'Access denied'
                });
            }

            await pool.query(
                'UPDATE students SET first_name = COALESCE(?, first_name), last_name = COALESCE(?, last_name), email = COALESCE(?, email), date_of_birth = COALESCE(?, date_of_birth), address = COALESCE(?, address), phone = COALESCE(?, phone) WHERE id = ?',
                [first_name, last_name, email, date_of_birth, address, phone, studentId]
            );

            res.json({
                success: true,
                message: 'Student profile updated successfully'
            });
        } catch (error) {
            console.error(error);
            res.status(500).json({
                success: false,
                message: 'Error updating student profile'
            });
        }
    }
);

// Get student's enrolled courses
router.get('/:id/courses',
    authenticateToken,
    async (req, res) => {
        try {
            const studentId = req.params.id;

            // Check if student exists and user has permission
            const [students] = await pool.query('SELECT user_id FROM students WHERE id = ?', [studentId]);
            if (students.length === 0) {
                return res.status(404).json({
                    success: false,
                    message: 'Student not found'
                });
            }

            if (req.user.role === 'student' && req.user.id !== students[0].user_id) {
                return res.status(403).json({
                    success: false,
                    message: 'Access denied'
                });
            }

            const [courses] = await pool.query(
                `SELECT c.*, sc.enrollment_date, sc.status
                FROM courses c
                JOIN student_courses sc ON c.id = sc.course_id
                WHERE sc.student_id = ?`,
                [studentId]
            );

            res.json({
                success: true,
                courses
            });
        } catch (error) {
            console.error(error);
            res.status(500).json({
                success: false,
                message: 'Error fetching student courses'
            });
        }
    }
);

export default router;