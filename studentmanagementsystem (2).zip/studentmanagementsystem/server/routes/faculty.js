import express from 'express';
import { check } from 'express-validator';
import pool from '../config/db.js';
import { authenticateToken, authorizeRole, validateRequest } from '../middleware/auth.js';

const router = express.Router();

// Get all faculty members (admin only)
router.get('/',
    authenticateToken,
    authorizeRole('admin'),
    async (req, res) => {
        try {
            const [faculty] = await pool.query(
                'SELECT f.*, u.username, u.role FROM faculty f JOIN users u ON f.user_id = u.id'
            );
            res.json({
                success: true,
                faculty
            });
        } catch (error) {
            console.error(error);
            res.status(500).json({
                success: false,
                message: 'Error fetching faculty members'
            });
        }
    }
);

// Get faculty member by ID
router.get('/:id',
    authenticateToken,
    async (req, res) => {
        try {
            const [faculty] = await pool.query(
                'SELECT f.*, u.username, u.role FROM faculty f JOIN users u ON f.user_id = u.id WHERE f.id = ?',
                [req.params.id]
            );

            if (faculty.length === 0) {
                return res.status(404).json({
                    success: false,
                    message: 'Faculty member not found'
                });
            }

            // Check if user has permission to view this faculty member
            if (req.user.role === 'teacher' && req.user.id !== faculty[0].user_id) {
                return res.status(403).json({
                    success: false,
                    message: 'Access denied'
                });
            }

            res.json({
                success: true,
                faculty: faculty[0]
            });
        } catch (error) {
            console.error(error);
            res.status(500).json({
                success: false,
                message: 'Error fetching faculty member'
            });
        }
    }
);

// Create faculty profile (admin only)
router.post('/',
    authenticateToken,
    authorizeRole('admin'),
    [
        check('user_id').notEmpty().withMessage('User ID is required'),
        check('first_name').notEmpty().withMessage('First name is required'),
        check('last_name').notEmpty().withMessage('Last name is required'),
        check('email').isEmail().withMessage('Invalid email'),
        check('department').notEmpty().withMessage('Department is required')
    ],
    validateRequest,
    async (req, res) => {
        try {
            const { user_id, first_name, last_name, email, department, phone } = req.body;

            // Check if user exists and is a teacher
            const [users] = await pool.query('SELECT role FROM users WHERE id = ?', [user_id]);
            if (users.length === 0 || users[0].role !== 'teacher') {
                return res.status(400).json({
                    success: false,
                    message: 'Invalid user ID or user is not a teacher'
                });
            }

            // Check if faculty profile already exists
            const [existingFaculty] = await pool.query('SELECT id FROM faculty WHERE user_id = ?', [user_id]);
            if (existingFaculty.length > 0) {
                return res.status(400).json({
                    success: false,
                    message: 'Faculty profile already exists'
                });
            }

            const [result] = await pool.query(
                'INSERT INTO faculty (user_id, first_name, last_name, email, department, phone) VALUES (?, ?, ?, ?, ?, ?)',
                [user_id, first_name, last_name, email, department, phone]
            );

            res.status(201).json({
                success: true,
                message: 'Faculty profile created successfully',
                facultyId: result.insertId
            });
        } catch (error) {
            console.error(error);
            res.status(500).json({
                success: false,
                message: 'Error creating faculty profile'
            });
        }
    }
);

// Update faculty profile
router.put('/:id',
    authenticateToken,
    [
        check('first_name').optional().notEmpty().withMessage('First name cannot be empty'),
        check('last_name').optional().notEmpty().withMessage('Last name cannot be empty'),
        check('email').optional().isEmail().withMessage('Invalid email'),
        check('department').optional().notEmpty().withMessage('Department cannot be empty')
    ],
    validateRequest,
    async (req, res) => {
        try {
            const facultyId = req.params.id;
            const { first_name, last_name, email, department, phone } = req.body;

            // Check if faculty exists
            const [faculty] = await pool.query('SELECT user_id FROM faculty WHERE id = ?', [facultyId]);
            if (faculty.length === 0) {
                return res.status(404).json({
                    success: false,
                    message: 'Faculty member not found'
                });
            }

            // Check if user has permission to update this faculty member
            if (req.user.role === 'teacher' && req.user.id !== faculty[0].user_id) {
                return res.status(403).json({
                    success: false,
                    message: 'Access denied'
                });
            }

            await pool.query(
                'UPDATE faculty SET first_name = COALESCE(?, first_name), last_name = COALESCE(?, last_name), email = COALESCE(?, email), department = COALESCE(?, department), phone = COALESCE(?, phone) WHERE id = ?',
                [first_name, last_name, email, department, phone, facultyId]
            );

            res.json({
                success: true,
                message: 'Faculty profile updated successfully'
            });
        } catch (error) {
            console.error(error);
            res.status(500).json({
                success: false,
                message: 'Error updating faculty profile'
            });
        }
    }
);

// Get faculty member's assigned courses
router.get('/:id/courses',
    authenticateToken,
    async (req, res) => {
        try {
            const facultyId = req.params.id;

            // Check if faculty exists and user has permission
            const [faculty] = await pool.query('SELECT user_id FROM faculty WHERE id = ?', [facultyId]);
            if (faculty.length === 0) {
                return res.status(404).json({
                    success: false,
                    message: 'Faculty member not found'
                });
            }

            if (req.user.role === 'teacher' && req.user.id !== faculty[0].user_id) {
                return res.status(403).json({
                    success: false,
                    message: 'Access denied'
                });
            }

            const [courses] = await pool.query(
                'SELECT * FROM courses WHERE faculty_id = ?',
                [facultyId]
            );

            res.json({
                success: true,
                courses
            });
        } catch (error) {
            console.error(error);
            res.status(500).json({
                success: false,
                message: 'Error fetching faculty courses'
            });
        }
    }
);

export default router;